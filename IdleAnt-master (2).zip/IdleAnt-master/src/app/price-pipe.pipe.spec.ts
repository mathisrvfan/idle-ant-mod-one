import { PricePipePipe } from './price-pipe.pipe';

describe('PricePipePipe', () => {
  it('create an instance', () => {
    const pipe = new PricePipePipe();
    expect(pipe).toBeTruthy();
  });
});
