export interface WorldInterface {

  declareStuff()

  initStuff()

  addWorld()

}
