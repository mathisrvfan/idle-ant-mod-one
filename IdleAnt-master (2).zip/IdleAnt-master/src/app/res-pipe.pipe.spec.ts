import { ResPipePipe } from './res-pipe.pipe';

describe('ResPipePipe', () => {
  it('create an instance', () => {
    const pipe = new ResPipePipe();
    expect(pipe).toBeTruthy();
  });
});
