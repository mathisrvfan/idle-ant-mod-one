import { ProdToglePipePipe } from './prod-togle-pipe.pipe';

describe('ProdToglePipePipe', () => {
  it('create an instance', () => {
    const pipe = new ProdToglePipePipe();
    expect(pipe).toBeTruthy();
  });
});
