import { Event } from '@angular/router';
import { ChangeDetectionStrategy, Component, OnInit, HostBinding } from '@angular/core';
import { GameService } from '../game.service';

declare let preventScroll

@Component({
  selector: 'app-options',
  templateUrl: './options.component.html',
  styleUrls: ['./options.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class OptionsComponent implements OnInit {
  @HostBinding('class.content-area') className = 'content-area'

  stringSave = ""

  constructor(public gameService: GameService) { }

  ngOnInit() {
    preventScroll()
  }

  save(event: Event) { this.gameService.save(false) }
  load(event: Event) { this.gameService.load() }
  clear(event: Event) { this.gameService.clear() }

  export(event: Event) {
    this.stringSave = this.gameService.game.getSave()
  }

  import(event: Event) {
    this.gameService.game.load(this.stringSave.trim())
  }

}
