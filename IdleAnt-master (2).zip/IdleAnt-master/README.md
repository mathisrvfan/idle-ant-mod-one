# IdleAnt
Idle Ant is an incremental game about ants.

The game uses [Angular 4](https://angular.io/), [Clarity Design System](https://vmware.github.io/clarity/) and some other library.

Links:

Github:

https://scorzy.github.io/IdleAnt

kongregate:

http://www.kongregate.com/games/scorzy88/idle-ants

Play Store:

https://play.google.com/store/apps/details?id=it.lorenzo.idleants
